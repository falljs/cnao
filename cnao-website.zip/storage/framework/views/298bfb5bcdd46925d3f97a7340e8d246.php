<?php $__env->startSection('pageTitle', $pageTitle ?? 'Détails du service - CNAO'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Hero Start -->
    <div class="container-fluid bg-primary py-5 hero-header mb-5">
        <div class="row py-3">
            <div class="col-12 text-center">
                <h1 class="display-4 text-white animated zoomIn">
                    <?php echo e($service->title); ?>

                </h1>
                <a href="<?php echo e(url('/')); ?>" class="h5 text-white">Accueil</a>
                <i class="far fa-circle text-white px-2"></i>
                <a href="<?php echo e(route('services.show', $service)); ?>" class="h5 text-white">
                    Service
                </a>
            </div>
        </div>
    </div>
    <!-- Hero End -->

    <!-- Service Details Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="row g-5 align-items-center">

                <!-- Content -->
                <div class="col-lg-7">
                    <div class="section-title mb-4">
                        <h5 class="position-relative d-inline-block text-primary text-uppercase">
                            Service CNAO
                        </h5>
                        <h1 class="display-5 mb-0">
                            <?php echo e($service->title); ?>

                        </h1>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($service->department): ?>
                        <h4 class="text-body fst-italic mb-4">
                            <?php echo e($service->department); ?>

                        </h4>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="mb-4">
                        <?php echo $service->description; ?>

                    </div>

                    
                </div>

                <!-- Image -->
                <div class="col-lg-5" style="min-height: 450px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100 rounded wow zoomIn" data-wow-delay="0.3s"
                            src="<?php echo e(asset('storage/' . $service->image)); ?>" alt="<?php echo e($service->title); ?>"
                            style="object-fit: cover;">
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Service Details End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\Assane seck\cnao-website\resources\views/serv_detail.blade.php ENDPATH**/ ?>