<div>
    <!-- resources/views/livewire/newsletter-form.blade.php -->

    <form wire:submit.prevent="submit" class="mx-auto" style="max-width: 600px;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($successMessage): ?>
            <div class="alert alert-success mb-3 text-center">
                Merci pour votre abonnement ✅
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="input-group">
            <input wire:model.defer="contact" type="text" class="form-control border-white p-3"
                placeholder="Votre Email ou Téléphone">

            <button class="btn btn-dark px-4">
                S'abonner
            </button>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger d-block mt-2 text-center">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>

</div>
<?php /**PATH C:\Users\HP\Downloads\Assane seck\cnao-website\resources\views/livewire/newsletter-form.blade.php ENDPATH**/ ?>